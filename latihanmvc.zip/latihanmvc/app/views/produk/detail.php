<?php

echo "<table>
<td><img src='" . BASEURL . "/" . $data['barang']['gambar_p'] . "' width='175'></td>
<td>Nama:".$data['barang']['nama']."
<br>
Harga: ".$data['barang']['harga']."
<br>
Exp: ".$data['barang']['expired']."
<br>
Merk: ".$data['barang']['Merk']."
<br>
Distributor: ".$data['barang']['distributor']."
<br>
</td>
<table>
<br>";
echo "<a href='" . BASEURL . "/home' class='card-link'>Kembali</a>";